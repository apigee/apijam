Friday, 21 June 2019, 14:00

population data is From
https://datahub.io/core/population#resource-population_zip

country-to-zone mapping is from
http://www.ipdeny.com/ipblocks/


Another option for the latter is :
https://www.nirsoft.net/countryip/
